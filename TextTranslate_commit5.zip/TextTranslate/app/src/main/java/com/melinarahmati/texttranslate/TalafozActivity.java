package com.melinarahmati.texttranslate;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
import android.view.View;
import android.widget.Toast;
import android.content.Intent;

public class TalafozActivity extends Activity {
    
    TextView tvShow;
    Button btnTalafoz;
    TextToSpeech tts1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talafoz);
        
        tvShow = findViewById(R.id.txt_showtalafoz);
        btnTalafoz = findViewById(R.id.btn_talafoz);
        
        Intent intent = getIntent();
        tvShow.setText(intent.getStringExtra("jomle"));
        
        tts1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if(status != TextToSpeech.ERROR) {
                        tts1.setLanguage(Locale.UK);
                    }
                }
            });

        btnTalafoz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String toSpeak = tvShow.getText().toString();
                    Toast.makeText(getApplicationContext(), toSpeak,Toast.LENGTH_SHORT).show();
                    tts1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
                }
            });
    }

    public void onPause(){
        if(tts1 !=null){
            tts1.stop();
            tts1.shutdown();
        }
        super.onPause();
    }
    
}
