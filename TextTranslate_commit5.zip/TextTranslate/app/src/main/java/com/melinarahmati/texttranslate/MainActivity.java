package com.melinarahmati.texttranslate;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.ImageView;
import android.text.TextWatcher;
import android.text.Editable;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private static final String TAG = "MainActivity";
    EditText edGetWord;
    TextView txtShowWordMain;
    Button btnNextPage,btnTranslate;
    ImageView imgPersian,imgEnglish,imgChange;
    int a = 0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
        edGetWord = findViewById(R.id.ed_gettext);
        txtShowWordMain = findViewById(R.id.txt_show_translate);
        btnNextPage = findViewById(R.id.btn_nextpage);
        imgEnglish = findViewById(R.id.img_england);
        imgPersian = findViewById(R.id.img_persian);
        imgChange = findViewById(R.id.img_change);
         
        
        edGetWord.addTextChangedListener(new TextWatcher() {
                @Override
                public void afterTextChanged(Editable s) {}

                @Override
                public void beforeTextChanged(CharSequence s, int start,
                                              int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start,
                                          int before, int count) {
                    if(!s.equals("")){
                      if(a == 0){
                          EnglishToPersian();
                      }else if(a == 1){
                          PersianToEnglish();
                      }  
                    }else
                    {
                        Toast.makeText(getApplicationContext(),"لطفا یک عبارت را وارد کنید",Toast.LENGTH_SHORT).show();
                    }
                        
                }
            });
            
        imgChange.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
               if(a == 0){
               imgEnglish.setImageResource(R.drawable.ic_persian);
               imgPersian.setImageResource(R.drawable.ic_english);
               edGetWord.setText(txtShowWordMain.getText().toString());
               a ++;
               }
               else if(a == 1){
                   imgEnglish.setImageResource(R.drawable.ic_english);
                   imgPersian.setImageResource(R.drawable.ic_persian);
                   edGetWord.setText(txtShowWordMain.getText().toString());
                   a --;
               }
            }
        });
        
        btnNextPage.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1) {
                    Intent intent = new Intent(MainActivity.this,TalafozActivity.class);
                    if(a == 0){
                    intent.putExtra("jomle",edGetWord.getText().toString());
                    startActivity(intent);
                    }else if(a == 1){
                        intent.putExtra("jomle",txtShowWordMain.getText().toString());
                        startActivity(intent);
                    }
                    }   
                });
        
    }
    
    private void EnglishToPersian(){
        TranslateAPI translateAPI = new TranslateAPI(
            Language.ENGLISH,
            Language.PERSIAN,
            edGetWord.getText().toString());

        translateAPI.setTranslateListener(new TranslateAPI.TranslateListener() {
                @Override
                public void onSuccess(String translatedText) {
                    Log.d(TAG, "onSuccess: "+translatedText);
                    txtShowWordMain.setText(translatedText);
                }

                @Override
                public void onFailure(String ErrorText) {
                    Log.d(TAG, "onFailure: "+ErrorText);
                }
            });

    }
    
    private void PersianToEnglish(){
        TranslateAPI translateAPIFe = new TranslateAPI(
            Language.PERSIAN,
            Language.ENGLISH,
            edGetWord.getText().toString());

        translateAPIFe.setTranslateListener(new TranslateAPI.TranslateListener() {
                @Override
                public void onSuccess(String translatedText) {
                    Log.d(TAG, "onSuccess: "+translatedText);
                    txtShowWordMain.setText(translatedText);
                }

                @Override
                public void onFailure(String ErrorText) {
                    Log.d(TAG, "onFailure: "+ErrorText);
                }
            });

    }
    
   
}
